class BlankStringError < StandardError

  def message
    "Blank string entered"
  end

end
