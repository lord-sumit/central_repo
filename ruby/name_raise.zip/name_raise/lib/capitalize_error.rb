class CapitalizeError < StandardError

  def message
    "Entered string is not capitalized"
  end

end
